const common = require("./common_function");
common.waitforauto()
common.requestScreen()
events.observeKey();
events.onKeyDown("volume_down", function(event){
    log("音量下键被按下了，亮屏，并退出脚本");
    common.liangping()
    exit()
});
events.onKeyDown("volume_up", function(event){
    log("音量上键被按下了，亮屏，并退出脚本");
    common.liangping()
    exit()
});
//启用按键监听
/* events.observeKey();
//监听音量上键按下
events.onKeyDown("volume_up", function(event){
    log("音量上键被按下了");
});
//监听菜单键按下
events.onKeyDown("menu", function(event){
    log("菜单键被按下了");
    exit();
}); */

log("执行黑屏脚本");
common.mieping()